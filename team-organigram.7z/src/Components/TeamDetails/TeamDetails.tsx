import React, { FC, ReactElement } from 'react';
import { Button, createMuiTheme, Grid, Paper, Typography } from '@material-ui/core';
import { PanoramaFishEye, Group } from '@material-ui/icons';
import './TeamDetails.css'
import slack from './slack.png';

interface TeamDetailsProps {
}

export const TeamDetails: FC<TeamDetailsProps> = ({ }): ReactElement => {

    // const slackLink = `slack://channel?team=${team.slackTeamId}&id=${team.slackChannelId}`;
    const slackLink = `slack://channel?team=TODO&id=TODO`;

    return (
        <div className='parent-container'>
            <Grid container justify='space-between'>
                <Grid item>
                    <Typography variant="h5" className='team-name'>Team Site Reliability Engineering</Typography>

                </Grid>
                <Grid item>
                    <Button className='slack-link' variant="contained" color='default' href={slackLink} startIcon={<img src={slack} width={16} />}>
                        Contact us via Slack
                    </Button>
                </Grid>
            </Grid>

            <div>
                <p>
                    The Site Reliability Engineering (SRE) team is taking care of our improving and maintaining our service platform, automating processes, and handling internal IT topics.
                    This team's primary goal is to create highly reliable, scalable services and systems for our customers, both internal and external.
                </p>
                <ul>
                    <li>
                        <b>Service reliability:</b> The SRE team is responsible for managing the (cloud and on-premise) infrastructure our services are running on.
                        This is not only limited to creating these resources, but also includes introducing proper tools and processes to ensure their availability and resilience.
                    </li>
                    <li>
                        <b>Platform policies, templates &amp; blueprints:</b> The SRE team coordinates and - together with the engineering team - builds the computation and data platform our services run on.
                        Among other topics, this includes the preparation of well-defined blueprints or sample projects for new services and infrastructure, and the infrastructure architecture they run on.
                    </li>
                    <li>
                        <b>Fast prototyping:</b> Simplified by the teams' agile nature, SRE often takes care of rapidly iterating on prototypes of new products or services.
                    </li>
                    <li>
                        <b>Internal IT:</b> While most of our IT relies on cloud systems, it still needs to be maintained properly to provide an ideal experience to all members of fiskaltrust.
                        This topic e.g. includes managing the Azure Active Directory (i.e. the user and group structure), Teams/the phone system, Slack, and other internal services.<br />
                        For maintenance work on hardware systems (e.g. office networking), we regularly cooperate with external partners like ACP.
                    </li>
                </ul>
            </div>

        </div>
    );
}

