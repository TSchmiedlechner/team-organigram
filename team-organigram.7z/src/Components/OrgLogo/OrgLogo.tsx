import './OrgLogo.css'

export const OrgLogo = () => {
    return (
        <div className='logo-container'>
            <img src="/images/logo.png" className='org-logo' alt="image" />
        </div>
    );
}

