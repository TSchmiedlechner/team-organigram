import logo from './logo.png';
import github from './github.png';
import './App.css';
import { AppBar, Button, Grid, IconButton, Paper, Toolbar, Typography } from '@material-ui/core';
import { OrgLogo } from './Components/OrgLogo/OrgLogo';
import { OrgStatistics } from './Components/OrgStatistics/OrgStatistics';
import { TeamDetails } from './Components/TeamDetails/TeamDetails';
import { ChartLegend } from './Components/ChartLegend/ChartLegend';

const ReactD3Pack = require('./Components/ReactD3Pack/ReactD3Pack').default;

function App() {

  return (
    <div>
      <AppBar position="static">
        <Toolbar>
          <IconButton edge="start" color="inherit" aria-label="menu">
            <img src={logo} alt="Team Circles" width="40" height="40"></img>
          </IconButton>
          <Typography variant="h6" style={{ flexGrow: 1 }}>
            Team Circles
          </Typography>
          <IconButton color="primary" aria-label="Contribute on GitHub" href='https://github.com/tschmiedlechner/team-organigram' title='GitHub' target='_blank'>
            <img src={github} alt="github" width="32" height="32" className="rounded-circle"></img>
          </IconButton>
        </Toolbar>
      </AppBar>

      <Grid container>
        <Grid item md={6}>
          <div style={{ margin: 'auto 70px' }}>
            <ReactD3Pack json="http://192.168.0.25:8080/flare.json"></ReactD3Pack>
          </div>
          <p style={{ fontStyle: 'italic', textAlign: 'center' }}>Click inside the chart to navigate between teams.</p>
        </Grid>
        <Grid item md={6} style={{padding: '0 50px'}}>
            <OrgLogo />
            <OrgStatistics numberOfMembers={28} numberOfTeams={12} />
            <TeamDetails />
            <ChartLegend />
        </Grid>
      </Grid>

    </div>

    // <div className='container-fluid'>
    //   <div className='border-bottom mb-4 row'>
    //     <div className='container'>
    //       <header className="d-flex flex-wrap justify-content-center py-3">
    //         <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
    //           <img src={logo} alt="Team Circles" width="40" height="40" className="bi me-2"></img>

    //           <span className="fs-4"><strong>Team Circles</strong></span>
    //         </a>

    //         <ul className="nav">
    //           <li className="nav-item">
    //             <a href="https://github.com/tschmiedlechner/team-organigram" title='GitHub' target='_blank' className="nav-link" aria-current="page">
    //               <img src={github} alt="github" width="32" height="32" className="rounded-circle"></img>
    //             </a>
    //           </li>
    //         </ul>
    //       </header>
    //     </div>
    //   </div>

    //   <div className='row'>
    //     <div className='col-md-6'>
    //       <div className='mx-5'>
    //         <ReactD3Pack json="http://192.168.0.25:8080/flare.json"></ReactD3Pack>
    //       </div></div>
    //     <div className='col-md-6' style={{ backgroundColor: "red" }}> asasdasd
    //     </div>
    //   </div>
    // </div>
  );
}

export default App;